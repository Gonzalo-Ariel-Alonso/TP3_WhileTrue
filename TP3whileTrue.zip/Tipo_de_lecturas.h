#ifndef TIPOS_DE_LECTURA_H
#define TIPOS_DE_LECTURA_H

enum Tipo_de_lecturas{NOVELA = 'N' , CUENTO = 'C' , POEMA = 'P', NOVELA_HISTORICA = 'H' };

#endif
